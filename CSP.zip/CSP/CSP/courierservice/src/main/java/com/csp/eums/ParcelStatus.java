package com.csp.eums;

public enum ParcelStatus {
	BOOKED,
	DELIVERED,
	REFUND,
	RETURNED,
	INTRANSPORT
}
