package com.csp.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csp.entity.ParcelDetails;
import com.csp.entity.TransportDetails;
import com.csp.entity.VehicleDetails;
import com.csp.exception.CourierServiceException;
import com.csp.repository.ParcelDetailsRepository;
import com.csp.repository.TransportDetailsRepository;
import com.csp.repository.VehicleDetailsRepository;
import com.csp.response.CourierServiceReportResponse;
import com.csp.service.ReportService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReportServiceImpl implements ReportService{
	
	private static final Logger log = LoggerFactory.getLogger(ReportServiceImpl.class);

	@Autowired
	ParcelDetailsRepository parcelDetailsRepository;
	
	@Autowired
	TransportDetailsRepository transportDetailsRepository;
	
	@Autowired
	VehicleDetailsRepository vehicleDetailsRepository;

	@Override
	public List<CourierServiceReportResponse> generateReport() throws CourierServiceException {
		TransportDetails transportDetails = new TransportDetails();
		List<CourierServiceReportResponse> courierServiceReportResponseList = new ArrayList<>();
		try {
			List<ParcelDetails> parcelDetailsList = parcelDetailsRepository.findAll();
			for (ParcelDetails parcelDetails : parcelDetailsList) {
				CourierServiceReportResponse response = new CourierServiceReportResponse();
				if (parcelDetails.getBookingId() != null && !parcelDetails.getBookingId().isEmpty()) {
					response.setParcelId(parcelDetails.getBookingId());
				}
				if (parcelDetails.getParcelWeight() != null) {
					response.setParcelWeight(parcelDetails.getParcelWeight());
				}
				if (parcelDetails.getPrice() != null) {
					response.setPrice(parcelDetails.getPrice());
				}
				if (parcelDetails.getParcelStatus() != null && !parcelDetails.getParcelStatus().isEmpty()) {
					response.setParcelStatus(parcelDetails.getParcelStatus());
				}
				if (parcelDetails.getRefundAmount() != null) {
					response.setRefundAmount(parcelDetails.getRefundAmount());
				}
				if (parcelDetails.getBookingId() != null && !parcelDetails.getBookingId().isEmpty()) {
					transportDetails = transportDetailsRepository.findByBookingId(parcelDetails.getBookingId());
				}

				Optional<VehicleDetails> vehicleDetails = vehicleDetailsRepository
						.findById(transportDetails.getVehicleNumber());
				if (transportDetails.getRouteNumber() != null) {
					response.setAssignedRouteNumber(transportDetails.getRouteNumber());
				}
				if (vehicleDetails.get().getRoute() != null && !vehicleDetails.get().getRoute().isEmpty()) {
					response.setRoute(vehicleDetails.get().getRoute());
				}
				if (vehicleDetails.get().getCost() != null && !vehicleDetails.get().getCost().isEmpty()) {
					response.setTransportCost(vehicleDetails.get().getCost());
				}
				if (transportDetails.getVehicleNumber() != null && !transportDetails.getVehicleNumber().isEmpty()) {
					response.setVehicleNumber(transportDetails.getVehicleNumber());
				}
				courierServiceReportResponseList.add(response);
			}
		} catch (Exception e) {
			log.error("Exception occurred while generating Courier Service Report");
			throw new CourierServiceException(e.getMessage());
		}
		return courierServiceReportResponseList;
	}

}
