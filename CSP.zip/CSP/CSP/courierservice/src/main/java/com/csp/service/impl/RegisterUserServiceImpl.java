package com.csp.service.impl;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.csp.entity.UserDetails;
import com.csp.exception.CourierServiceException;
import com.csp.repository.UserDetailsRepository;
import com.csp.request.RegisterUserRequest;
import com.csp.response.RegisterUserResponse;
import com.csp.service.RegisterUserService;

@Service
public class RegisterUserServiceImpl implements RegisterUserService{
	
	private static final Logger log = LoggerFactory.getLogger(RegisterUserServiceImpl.class);
	
	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Override
	public RegisterUserResponse registerUser(RegisterUserRequest registerUserRequest, HttpHeaders httpHeaders) throws CourierServiceException {
		RegisterUserResponse response = new RegisterUserResponse();
		try {
			UUID uuid = UUID.randomUUID();
			String userId = uuid.toString();
			saveUserDetails(userId, registerUserRequest);
			response.setUserId(userId);
			response.setUserEmail(registerUserRequest.getUserEmail());
			response.setUserRole(registerUserRequest.getUserRole());
			response.setStatus("CREATED");
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return response;
	}

	private void saveUserDetails(String userId, RegisterUserRequest registerUserRequest) {

		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(userId);
		if (registerUserRequest.getFirstName() != null && !registerUserRequest.getFirstName().isEmpty()) {
			userDetails.setFirstName(registerUserRequest.getFirstName());
		}
		if (registerUserRequest.getLastName() != null && !registerUserRequest.getLastName().isEmpty()) {
			userDetails.setLastName(registerUserRequest.getLastName());
		}
		if (registerUserRequest.getUserEmail() != null && !registerUserRequest.getUserEmail().isEmpty()) {
			userDetails.setEmail(registerUserRequest.getUserEmail());
		}
		if (registerUserRequest.getUserRole() != null && !registerUserRequest.getUserRole().isEmpty()) {
			userDetails.setUserRole(registerUserRequest.getUserRole());
		}
		if (registerUserRequest.getPassword() != null && !registerUserRequest.getPassword().isEmpty()) {
			userDetails.setPassword(registerUserRequest.getPassword());
		}
		userDetailsRepository.save(userDetails);
		log.info("User Details saved in DB");
	}
}
