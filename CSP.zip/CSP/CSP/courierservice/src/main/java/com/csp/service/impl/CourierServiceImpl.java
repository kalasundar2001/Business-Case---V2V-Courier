package com.csp.service.impl;

import java.util.Optional;
import java.util.Random;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.csp.entity.ParcelDetails;
import com.csp.eums.ParcelStatus;
import com.csp.exception.CourierServiceException;
import com.csp.repository.ParcelDetailsRepository;
import com.csp.request.BookParcelRequest;
import com.csp.response.BookParcelResponse;
import com.csp.response.RefundResponse;
import com.csp.service.CourierService;
import com.csp.util.Constants;

@Service
public class CourierServiceImpl implements CourierService{
	
	private static final Logger log = LoggerFactory.getLogger(CourierServiceImpl.class);
	
	@Autowired
	ParcelDetailsRepository parcelDetailsRepository;

	@Override
	public BookParcelResponse bookParcel(BookParcelRequest bookParcelRequest, HttpHeaders httpHeaders) throws CourierServiceException {
		
		BookParcelResponse response = new BookParcelResponse();
		try {
			Random r = new Random(System.currentTimeMillis());
			Long bookingId = (long) (10000 + r.nextInt(20000));
			String id = bookingId.toString();
			saveParcelDetails(id, bookParcelRequest);
			response.setBookingId(id);
			response.setBookingStatus(ParcelStatus.BOOKED.toString());
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return response;
	}
	
	@Override
	public BookParcelResponse getParcelDetails(String bookingId) throws CourierServiceException {
		BookParcelResponse response = new BookParcelResponse();
		try {
			Optional<ParcelDetails> parcelDetails = parcelDetailsRepository.findById(bookingId);
			if (parcelDetails.get().getBookingId() != null && !parcelDetails.get().getBookingId().isEmpty()) {
				response.setBookingId(parcelDetails.get().getBookingId());
			}
			if (parcelDetails.get().getParcelStatus() != null && !parcelDetails.get().getParcelStatus().isEmpty()) {
				response.setBookingStatus(parcelDetails.get().getParcelStatus());
			}
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return response;
	}
	
	@Override
	@Transactional
	public String updateParcelDetails(String bookingId, String status) throws CourierServiceException {
		try {
			Optional<ParcelDetails> pacelDetails = parcelDetailsRepository.findById(bookingId);
			if (pacelDetails.get().getBookingId() != null) {
				parcelDetailsRepository.updateParcelStatus(status, bookingId);
				log.info("Parcel status updated as {}", status);
				return Constants.PARCEL_STATUS_UPDATED;
			} else {
				return Constants.INVALID_PARCEL_ID;
			}
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
	}
	
	@Override
	@Transactional
	public RefundResponse refundAmount(String bookingId) throws CourierServiceException {
		RefundResponse refundResponse = new RefundResponse();
		try {
			Optional<ParcelDetails> parcelDetails = parcelDetailsRepository.findById(bookingId);
			long refundAmount = (parcelDetails.get().getPrice()) - (parcelDetails.get().getPrice() * 20 / 100);
			parcelDetailsRepository.updateParcelStatus(ParcelStatus.REFUND.toString(), bookingId);
			parcelDetailsRepository.updateRefundAmount(refundAmount, bookingId);
			refundResponse.setBookingId(bookingId);
			refundResponse.setRefundAmount(refundAmount);
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return refundResponse;
	}

	private void saveParcelDetails(String bookingId, BookParcelRequest bookParcelRequest) {

		ParcelDetails parcelDetails = new ParcelDetails();
		if (bookingId != null) {
			parcelDetails.setBookingId(bookingId);
		}
		if (bookParcelRequest.getName() != null && !bookParcelRequest.getName().isEmpty()) {
			parcelDetails.setName(bookParcelRequest.getName());
		}
		if (bookParcelRequest.getAddress() != null && !bookParcelRequest.getAddress().isEmpty()) {
			parcelDetails.setAddress(bookParcelRequest.getAddress());
		}
		if (bookParcelRequest.getCity() != null && !bookParcelRequest.getCity().isEmpty()) {
			parcelDetails.setCity(bookParcelRequest.getCity());
		}
		if (bookParcelRequest.getState() != null && !bookParcelRequest.getState().isEmpty()) {
			parcelDetails.setState(bookParcelRequest.getState());
		}
		parcelDetails.setParcelWeight(bookParcelRequest.getParcelWeight());
		parcelDetails.setPrice(bookParcelRequest.getPrice());
		parcelDetails.setParcelStatus(ParcelStatus.BOOKED.toString());
		parcelDetailsRepository.save(parcelDetails);
		log.info("Parcel Details are saved in DB");
	}

}
