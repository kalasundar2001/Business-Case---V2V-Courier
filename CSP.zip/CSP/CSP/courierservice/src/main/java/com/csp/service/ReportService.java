package com.csp.service;

import java.util.List;

import com.csp.exception.CourierServiceException;
import com.csp.response.CourierServiceReportResponse;

public interface ReportService {

	public List<CourierServiceReportResponse> generateReport() throws CourierServiceException;

}
