package com.csp.service;

import com.csp.exception.CourierServiceException;
import com.csp.request.RegisterVehicleRequest;
import com.csp.response.RegisterVehicleResponse;
import com.csp.response.TransportRouteResponse;

public interface TransportService {

	public RegisterVehicleResponse registerVehicle(RegisterVehicleRequest registerVehicleRequest) throws CourierServiceException;
	public TransportRouteResponse assignRoutes(String bookingId, String vehicleNumber) throws CourierServiceException;

}
