package com.csp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.csp.entity.VehicleDetails;

public interface VehicleDetailsRepository extends JpaRepository<VehicleDetails, String>{

}
