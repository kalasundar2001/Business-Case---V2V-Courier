package com.csp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.csp.entity.TransportDetails;

public interface TransportDetailsRepository extends JpaRepository<TransportDetails, String>{

	@Query("select td from TransportDetails td where td.parcelId = :parcelId")
	public TransportDetails findByBookingId(String parcelId);

}
