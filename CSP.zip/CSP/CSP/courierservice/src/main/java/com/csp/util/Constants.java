package com.csp.util;

public class Constants {

	public static final String COURIER_SERVICE_URI = "/csp";
	public static final String BOOK_PARCEL_URI = "/bookparcel";
	public static final String GET_PARCEL_STATUS_URI = "/getparceldetails";
	public static final String UPDATE_PARCEL_STATUS_URI = "/updateparceldetails";
	public static final String REGISTER_USER_URI = "/registeruser";
	public static final String UPDATE_REFUND_AMOUNT_URI = "/refund";
	public static final String REGISTER_VEHICLE_URI = "/registerVehicle";
	public static final String ASSIGN_ROUTES_URI = "/assignTransportRoute";
	public static final String GENERATE_REPORT = "/generateReport";
	
	public static final String PARCEL_STATUS_UPDATED = "Parcel Status Updated";
	public static final String REFUND_AMOUNT_STATUS = "Amount Refunded";
	public static final String REGISTERED = "REGISTERED";
	public static final String ROUTE_ASSIGNED = "ROUTE ASSIGNED";
	
	public static final String ERROR_001 = "ER001";
	public static final String ERROR_002 = "ER002";
	public static final String ERROR_003 = "ER003";
	public static final String ERROR_004 = "ER004";
	public static final String ERROR_005 = "ER005";
	public static final String ERROR_006 = "ER006";
	
	public static final String INVALID_PARCEL_ID = "Invalid Parcel ID. Please enter valid booking ID";
	public static final String BOOK_PARCEL_EXCEPTION_MESSAGE = "Exception occurred while booking Parcel";
	public static final String PARCEL_STATUS_EXCEPTION_MESSAGE = "Exception occurred while updating Parcel Status";
	public static final String REGISTER_USER_EXCEPTION_MESSAGE = "Failed to register User";
	public static final String REGISTER_VEHICLE_EXCEPTION_MESSAGE = "Failed to register Vehicle";
	public static final String ASSIGN_ROUTE_EXCEPTION_MESSAGE = "Failed to assign route for given Parcel Id";
}
