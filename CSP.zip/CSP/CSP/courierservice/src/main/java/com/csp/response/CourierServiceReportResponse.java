package com.csp.response;

public class CourierServiceReportResponse {

	private String parcelId;
	private long parcelWeight;
	private long price;
	private long refundAmount;
	private String parcelStatus;
	private long assignedRouteNumber;
	private String vehicleNumber;
	private String route;
	private String transportCost;

	public String getParcelId() {
		return parcelId;
	}

	public void setParcelId(String parcelId) {
		this.parcelId = parcelId;
	}

	public long getParcelWeight() {
		return parcelWeight;
	}

	public void setParcelWeight(long parcelWeight) {
		this.parcelWeight = parcelWeight;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public String getParcelStatus() {
		return parcelStatus;
	}

	public void setParcelStatus(String parcelStatus) {
		this.parcelStatus = parcelStatus;
	}

	public long getAssignedRouteNumber() {
		return assignedRouteNumber;
	}

	public void setAssignedRouteNumber(long assignedRouteNumber) {
		this.assignedRouteNumber = assignedRouteNumber;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public long getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(long refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTransportCost() {
		return transportCost;
	}

	public void setTransportCost(String transportCost) {
		this.transportCost = transportCost;
	}

}
