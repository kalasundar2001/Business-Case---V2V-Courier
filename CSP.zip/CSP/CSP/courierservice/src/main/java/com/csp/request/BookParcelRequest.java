package com.csp.request;

public class BookParcelRequest {

	private long parcelWeight;
	private long price;
	private String name;
	private String address;
	private String city;
	private String state;

	public long getParcelWeight() {
		return parcelWeight;
	}

	public void setParcelWeight(long parcelWeight) {
		this.parcelWeight = parcelWeight;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
}
