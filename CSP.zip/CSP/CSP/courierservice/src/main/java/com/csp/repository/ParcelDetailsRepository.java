package com.csp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.csp.entity.ParcelDetails;

public interface ParcelDetailsRepository extends JpaRepository<ParcelDetails, String>{

	@Modifying
	@Query("update ParcelDetails pd set pd.parcelStatus = :status where pd.bookingId = :bookingId")
	void updateParcelStatus(@Param("status") String status, @Param("bookingId") String bookingId);
	@Modifying
	@Query("update ParcelDetails pd set pd.refundAmount = :refundAmount where pd.bookingId = :bookingId")
	void updateRefundAmount(@Param("refundAmount") long refundAmount, @Param("bookingId") String bookingId);
	
}
