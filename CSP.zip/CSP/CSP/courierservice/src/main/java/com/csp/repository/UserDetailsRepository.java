package com.csp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.csp.entity.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{

}
