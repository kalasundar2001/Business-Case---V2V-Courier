package com.csp.service;

import org.springframework.http.HttpHeaders;

import com.csp.exception.CourierServiceException;
import com.csp.request.BookParcelRequest;
import com.csp.response.BookParcelResponse;
import com.csp.response.RefundResponse;

public interface CourierService {
	public BookParcelResponse bookParcel(BookParcelRequest bookParcelRequest, HttpHeaders httpHeaders) throws CourierServiceException;
	public BookParcelResponse getParcelDetails(String bookingId) throws CourierServiceException;
	public String updateParcelDetails(String bookingId, String status) throws CourierServiceException;
	public RefundResponse refundAmount(String bookingId) throws CourierServiceException;
}
