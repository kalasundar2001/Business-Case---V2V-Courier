package com.csp.service;

import org.springframework.http.HttpHeaders;

import com.csp.exception.CourierServiceException;
import com.csp.request.RegisterUserRequest;
import com.csp.response.RegisterUserResponse;

public interface RegisterUserService {

	public RegisterUserResponse registerUser(RegisterUserRequest registerUserRequest, HttpHeaders httpHeaders) throws CourierServiceException;

}
