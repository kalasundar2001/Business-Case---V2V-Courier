package com.csp.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csp.entity.TransportDetails;
import com.csp.entity.VehicleDetails;
import com.csp.exception.CourierServiceException;
import com.csp.repository.TransportDetailsRepository;
import com.csp.repository.VehicleDetailsRepository;
import com.csp.request.RegisterVehicleRequest;
import com.csp.response.RegisterVehicleResponse;
import com.csp.response.TransportRouteResponse;
import com.csp.service.TransportService;
import com.csp.util.Constants;

@Service
public class TransportServiceImpl implements TransportService{
	
	private static final Logger log = LoggerFactory.getLogger(TransportServiceImpl.class);
	
	@Autowired
	VehicleDetailsRepository vehicleDetailsRepository;
	
	@Autowired
	TransportDetailsRepository transportDetailsRepository;

	@Override
	public RegisterVehicleResponse registerVehicle(RegisterVehicleRequest registerVehicleRequest) throws CourierServiceException {
		RegisterVehicleResponse registerVehicleResponse = new RegisterVehicleResponse();
		try {
			saveVehicleDetails(registerVehicleRequest);
			registerVehicleResponse.setVehicleNumber(registerVehicleRequest.getVehicleNumber());
			registerVehicleResponse.setStatus(Constants.REGISTERED);
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return registerVehicleResponse;
	}

	@Override
	public TransportRouteResponse assignRoutes(String bookingId, String vehicleNumber) throws CourierServiceException {
		TransportRouteResponse transportRouteResponse = new TransportRouteResponse();
		try {
			saveTransportDetails(bookingId, vehicleNumber);
			transportRouteResponse.setParcelId(bookingId);
			transportRouteResponse.setStatus(Constants.ROUTE_ASSIGNED);
		} catch (Exception ex) {
			throw new CourierServiceException(ex.getMessage());
		}
		return transportRouteResponse;
	}
	
	private void saveVehicleDetails(RegisterVehicleRequest registerVehicleRequest) {
		VehicleDetails vehicleDetails = new VehicleDetails();
		if (registerVehicleRequest.getVehicleNumber() != null && !registerVehicleRequest.getVehicleNumber().isEmpty()) {
			vehicleDetails.setVehicleNumber(registerVehicleRequest.getVehicleNumber());
		}
		if (registerVehicleRequest.getRoute() != null && !registerVehicleRequest.getRoute().isEmpty()) {
			vehicleDetails.setRoute(registerVehicleRequest.getRoute());
		}
		if (registerVehicleRequest.getCost() != null && !registerVehicleRequest.getCost().isEmpty()) {
			vehicleDetails.setCost(registerVehicleRequest.getCost());
		}
		vehicleDetailsRepository.save(vehicleDetails);
		log.info("Vehicle Details saved in DB");
	}

	private void saveTransportDetails(String bookingId, String vehicleNumber) {
		TransportDetails transportDetails = new TransportDetails();
		transportDetails.setParcelId(bookingId);
		transportDetails.setVehicleNumber(vehicleNumber);
		transportDetailsRepository.save(transportDetails);
		log.info("Transport Details saved in DB");
	}
}
