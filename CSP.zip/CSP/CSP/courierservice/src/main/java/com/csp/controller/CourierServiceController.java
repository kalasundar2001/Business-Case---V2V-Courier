package com.csp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.csp.exception.CourierServiceException;
import com.csp.exception.Error;
import com.csp.request.BookParcelRequest;
import com.csp.request.RegisterUserRequest;
import com.csp.request.RegisterVehicleRequest;
import com.csp.response.BookParcelResponse;
import com.csp.response.CourierServiceReportResponse;
import com.csp.response.RefundResponse;
import com.csp.response.RegisterUserResponse;
import com.csp.response.RegisterVehicleResponse;
import com.csp.response.TransportRouteResponse;
import com.csp.service.CourierService;
import com.csp.service.RegisterUserService;
import com.csp.service.ReportService;
import com.csp.service.TransportService;
import com.csp.util.Constants;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(Constants.COURIER_SERVICE_URI)
@Slf4j
public class CourierServiceController {
	
	private static final Logger log = LoggerFactory.getLogger(CourierServiceController.class);
	
	@Autowired
	CourierService courierService;
	
	@Autowired
	RegisterUserService registerUserService;
	
	@Autowired
	TransportService transportService;
	
	@Autowired
	ReportService reportService;
	
	@PostMapping(path = {Constants.BOOK_PARCEL_URI}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> bookParcel(@RequestBody BookParcelRequest bookParcelRequest, @RequestHeader HttpHeaders httpHeaders) {
		try {
			BookParcelResponse bookParcelResponse = courierService.bookParcel(bookParcelRequest, httpHeaders);
			return new ResponseEntity<>(bookParcelResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while booking parcel");
			Error error = errorMessage(Constants.ERROR_001, Constants.BOOK_PARCEL_EXCEPTION_MESSAGE);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path = { Constants.GET_PARCEL_STATUS_URI }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getParcelStatus(@RequestParam String bookingId) {
		try {
			BookParcelResponse bookParcelResponse = courierService.getParcelDetails(bookingId);
			return new ResponseEntity<>(bookParcelResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while fetching parcel status");
			Error error = errorMessage(Constants.ERROR_002, Constants.INVALID_PARCEL_ID);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(path = Constants.UPDATE_PARCEL_STATUS_URI)
	public String updateParcelStatus(@RequestParam String bookingId, @RequestParam String status) {
			try {
			String response = courierService.updateParcelDetails(bookingId, status);
			return response;
		} catch (Exception e) {
			log.error("Exception Occurred while updating parcel status");
			return Constants.INVALID_PARCEL_ID;
		}
	}
	
	@PostMapping(path = {Constants.REGISTER_USER_URI}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> registerUser(@RequestBody RegisterUserRequest registerUserRequest, @RequestHeader HttpHeaders httpHeaders) {
		try {
			RegisterUserResponse registerResponse = registerUserService.registerUser(registerUserRequest, httpHeaders);
			return new ResponseEntity<>(registerResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while registering user");
			Error error = errorMessage(Constants.ERROR_003, Constants.REGISTER_USER_EXCEPTION_MESSAGE);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(path = Constants.UPDATE_REFUND_AMOUNT_URI, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> refundAmount(@RequestParam String bookingId) {
		try {
			RefundResponse refundResponse = courierService.refundAmount(bookingId);
			return new ResponseEntity<>(refundResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while updating refund amount");
			Error error = errorMessage(Constants.ERROR_004, Constants.INVALID_PARCEL_ID);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(path = Constants.REGISTER_VEHICLE_URI, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> registerVehicleDetails(@RequestBody RegisterVehicleRequest registerVehicleRequest) {
		try {
			RegisterVehicleResponse registerVehicleResponse = transportService.registerVehicle(registerVehicleRequest);
			return new ResponseEntity<>(registerVehicleResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while registering vehicle");
			Error error = errorMessage(Constants.ERROR_005, Constants.REGISTER_VEHICLE_EXCEPTION_MESSAGE);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(path = Constants.ASSIGN_ROUTES_URI)
	public ResponseEntity<Object> assignTransportRoute(@RequestParam String bookingId, @RequestParam String vehicleNumber) {
		try {
			TransportRouteResponse transportRouteResponse = transportService.assignRoutes(bookingId, vehicleNumber);
			return new ResponseEntity<>(transportRouteResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Occurred while assigning routes");
			Error error = errorMessage(Constants.ERROR_006, Constants.ASSIGN_ROUTE_EXCEPTION_MESSAGE);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path = Constants.GENERATE_REPORT)
	public ResponseEntity<List<CourierServiceReportResponse>> generateReport() throws CourierServiceException {
		List<CourierServiceReportResponse> response = reportService.generateReport();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	private Error errorMessage(String code, String userMessage) {
		Error error = new Error();
		error.setCode(code);
		error.setUserMessage(userMessage);
		return error;
	}
}
